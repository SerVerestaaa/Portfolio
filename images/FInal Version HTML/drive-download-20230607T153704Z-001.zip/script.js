document.addEventListener("DOMContentLoaded", function () {
    const carouselImages = document.querySelectorAll(".right img");
    let currentIndex = 0;
    const intervalTime = 3000; // Delay between slide transitions in milliseconds

    function nextImage() {
        carouselImages[currentIndex].classList.remove("active");
        currentIndex = (currentIndex + 1) % carouselImages.length;
        carouselImages[currentIndex].classList.add("active");
    }

    setInterval(nextImage, intervalTime);
});


